import os
import re
import subprocess
from datetime import datetime

def extract_date_from_filename(filename):
    """
    Extrai a data do nome do arquivo, normalizando espaços extras, e define o horário como 12:00 AM.
    """
    patterns = [
        r"(\d{4})[ -]*(\d{2})[ -]*(\d{2})",  # AAAA-MM-DD ou AAAA - MM - DD
        r"(\d{2})[ -]*(\d{2})[ -]*(\d{4})",  # DD-MM-AAAA ou DD - MM - AAAA
    ]

    for pattern in patterns:
        match = re.search(pattern, filename)
        if match:
            groups = [group.zfill(2) for group in match.groups()]  # Remove espaços extras e garante dois dígitos
            try:
                # Define a data extraída com horário fixo de 12:00 AM
                if len(groups[0]) == 4:  # AAAA no início
                    date = datetime.strptime("".join(groups), "%Y%m%d").strftime("%Y:%m:%d")
                else:  # AAAA no final
                    date = datetime.strptime("".join(groups), "%d%m%Y").strftime("%Y:%m:%d")
                return f"{date} 00:00:00"
            except ValueError:
                continue
    return None

def update_exif_dates(file_path, date, exiftool_path):
    """
    Atualiza os campos de data no EXIF da imagem ou vídeo com base no nome do arquivo usando exiftool.
    """
    try:
        if not os.path.isfile(exiftool_path):
            raise FileNotFoundError(f"ExifTool não encontrado no caminho especificado: {exiftool_path}")

        if file_path.lower().endswith(('.jpg', '.jpeg')):
            # Atualiza campos de data para imagens
            subprocess.run([
                exiftool_path,
                f"-DateTimeOriginal={date}",
                f"-CreateDate={date}",
                f"-ModifyDate={date}",
                "-overwrite_original",
                file_path
            ], check=True)
        elif file_path.lower().endswith(('.mp4', '.mov')):
            # Atualiza campos de data para vídeos
            subprocess.run([
                exiftool_path,
                f"-MediaCreateDate={date}",
                f"-CreateDate={date}",
                f"-ModifyDate={date}",
                "-overwrite_original",
                file_path
            ], check=True)
    except subprocess.CalledProcessError as e:
        raise Exception(f"Erro ao atualizar EXIF: {e}")

def update_file_creation_date(file_path, date):
    """
    Atualiza a data de criação do arquivo no sistema de arquivos.
    """
    try:
        timestamp = datetime.strptime(date, "%Y:%m:%d %H:%M:%S").timestamp()
        os.utime(file_path, (timestamp, timestamp))
    except Exception as e:
        raise Exception(f"Erro ao atualizar a data de criação: {e}")

def process_files_in_directory():
    """
    Processa todas as imagens e vídeos no diretório atual, copiando a data do campo "Date taken" para os metadados apropriados.
    """
    current_directory = os.getcwd()
    exiftool_path = os.path.join(current_directory, 'exiftool', 'exiftool.exe')
    errors = []  # Lista de arquivos que não foram processados

    for file in os.listdir(current_directory):
        if file.lower().endswith(('.jpg', '.jpeg', '.mp4', '.mov')):
            try:
                date = extract_date_from_filename(file)
                if date:
                    file_path = os.path.join(current_directory, file)
                    update_exif_dates(file_path, date, exiftool_path)
                    update_file_creation_date(file_path, date)
                    print(f"{file}: Data atualizada para {date}.")
                else:
                    raise ValueError("Data não encontrada no nome do arquivo.")
            except Exception as e:
                errors.append((file, str(e)))

    # Gera relatório de erros
    if errors:
        print("\nRelatório de Erros:")
        for file, error in errors:
            print(f"{file}: {error}")
    else:
        print("\nTodos os arquivos foram processados com sucesso.")

# Uso
if __name__ == "__main__":
    process_files_in_directory()
