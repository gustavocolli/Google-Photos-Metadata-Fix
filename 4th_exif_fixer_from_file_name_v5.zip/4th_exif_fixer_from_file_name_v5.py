import os
import re
import subprocess
from datetime import datetime

def extract_date_from_filename(filename):
    """
    Tenta identificar a data no nome do arquivo usando múltiplos padrões.
    """
    patterns = [
        r"(\d{4})(\d{2})(\d{2})",            # AAAAMMDD
        r"(\d{4})-(\d{2})-(\d{2})",          # AAAA-MM-DD
        r"(\d{2})-(\d{2})-(\d{4})",          # DD-MM-AAAA
        r"(\d{2})_(\d{2})_(\d{4})",          # DD_MM_AAAA
    ]

    for pattern in patterns:
        match = re.search(pattern, filename)
        if match:
            groups = match.groups()
            if len(groups) == 3:
                try:
                    # Tenta criar uma data válida
                    if len(groups[0]) == 4:  # AAAA no início
                        date = datetime.strptime("".join(groups), "%Y%m%d").strftime("%Y:%m:%d %H:%M:%S")
                    else:  # AAAA no final
                        date = datetime.strptime("".join(groups), "%d%m%Y").strftime("%Y:%m:%d %H:%M:%S")
                    return date
                except ValueError:
                    continue
    return None

def update_exif_dates(image_path, date, exiftool_path):
    """
    Atualiza os campos de data no EXIF da imagem com base no nome do arquivo usando exiftool.
    """
    try:
        if not os.path.isfile(exiftool_path):
            raise FileNotFoundError(f"ExifTool não encontrado no caminho especificado: {exiftool_path}")

        subprocess.run([
            exiftool_path,
            f"-DateTimeOriginal={date}",
            f"-CreateDate={date}",
            f"-ModifyDate={date}",
            "-overwrite_original",
            image_path
        ], check=True)
        print(f"EXIF atualizado para {os.path.basename(image_path)} com a data {date}.")
    except subprocess.CalledProcessError as e:
        print(f"Erro ao atualizar EXIF para {os.path.basename(image_path)}: {e}")
    except FileNotFoundError as e:
        print(e)

def update_file_creation_date(file_path, date):
    """
    Atualiza a data de criação do arquivo no sistema de arquivos.
    """
    try:
        timestamp = datetime.strptime(date, "%Y:%m:%d %H:%M:%S").timestamp()
        os.utime(file_path, (timestamp, timestamp))
        print(f"Data de criação atualizada para {os.path.basename(file_path)} com a data {date}.")
    except Exception as e:
        print(f"Erro ao atualizar a data de criação para {os.path.basename(file_path)}: {e}")

def process_images_in_directory():
    """
    Processa todas as imagens no diretório atual, copiando a data do campo "Date taken" para o campo "Date created".
    """
    current_directory = os.getcwd()
    exiftool_path = os.path.join(current_directory, 'exiftool', 'exiftool.exe')
    for file in os.listdir(current_directory):
        if file.lower().endswith(('.jpg', '.jpeg')):
            date = extract_date_from_filename(file)
            if date:
                image_path = os.path.join(current_directory, file)
                update_exif_dates(image_path, date, exiftool_path)
                update_file_creation_date(image_path, date)
            else:
                print(f"Data não encontrada no nome do arquivo: {file}")

# Uso
if __name__ == "__main__":
    process_images_in_directory()