O programa vai ler o nome do arquivo e tentar modificar no exif utilizando a ferramenta exiftool. A pasta do exiftool deve estar na pasta onde se deseja rodar o script. Então por exemplo a pasta "Fotos_de_2022" deverá conter o script 4th_exif_fixer e a pasta Exiftool
O script tentará ajustar:

para fotos:
Date taken
Date created

para vídeos:
media taken
Date created

Obs: Filtre a mídia que já contém essa informação para não estragar os dados de exif da imagem/vídeo